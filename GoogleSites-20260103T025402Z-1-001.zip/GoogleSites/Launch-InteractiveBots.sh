#!/bin/bash
open "interactive-bots.html" || xdg-open "interactive-bots.html"
