#!/bin/bash
# Hydra-Terra 2025 World - Start Here (macOS/Linux)
# Launches the unified dashboard in the default browser

clear
echo "Launching HYDRA-TERRA 2025 WORLD..."

APP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

if [[ "$OSTYPE" == "darwin"* ]]; then
    open "$APP_DIR/hydra-terra-2025-world.html"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    xdg-open "$APP_DIR/hydra-terra-2025-world.html"
else
    echo "Unsupported OS for this launcher."
fi

sleep 1
