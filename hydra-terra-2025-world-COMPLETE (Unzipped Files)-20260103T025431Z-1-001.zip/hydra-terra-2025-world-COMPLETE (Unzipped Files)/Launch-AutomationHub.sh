#!/bin/bash
open "automation-hub.html" || xdg-open "automation-hub.html"
