#!/bin/bash
open "gps-tracker.html" || xdg-open "gps-tracker.html"
