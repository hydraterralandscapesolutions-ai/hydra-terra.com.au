#!/bin/bash
open "onboarding-gameshow.html" || xdg-open "onboarding-gameshow.html"
