#!/bin/bash
open "media-player.html" || xdg-open "media-player.html"
