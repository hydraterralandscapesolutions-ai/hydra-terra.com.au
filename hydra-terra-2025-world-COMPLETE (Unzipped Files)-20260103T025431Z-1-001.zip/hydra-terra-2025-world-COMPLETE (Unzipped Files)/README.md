# HYDRA-TERRA 2025 WORLD - Quick Deploy Guide

## 🚀 Get Live in 5 Minutes

### Step 1: Upload to GitHub
1. Go to https://github.com/new
2. Create a new repo (name it `hydra-terra-2025` or anything you like)
3. Make it **Public** (required for free GitHub Pages)
4. Click "Create repository"

### Step 2: Upload Files
1. On your new repo page, click "uploading an existing file"
2. Drag ALL files from the `GoogleSites` folder into the upload box
3. Make sure these files are included:
   - index.html (auto-redirects to dashboard)
   - hydra-terra-2025-world.html (main dashboard)
   - CNAME (contains your domain)
   - All .html tool files
   - HYDRA-TERRA_CERTIFICATE.txt
4. Click "Commit changes"

### Step 3: Enable GitHub Pages
1. In your repo, click "Settings"
2. Scroll to "Pages" in the left menu
3. Under "Source", select:
   - Branch: **main**
   - Folder: **/ (root)**
4. Click "Save"
5. Wait 1-2 minutes for deployment

### Step 4: Configure DNS (at your domain registrar)
Add these records for **hydra-terra.com.au**:

**A Records (for apex domain):**
- 185.199.108.153
- 185.199.109.153
- 185.199.110.153
- 185.199.111.153

**CNAME Record (for www):**
- Name: www
- Value: YOUR-GITHUB-USERNAME.github.io

*Replace YOUR-GITHUB-USERNAME with your actual GitHub username*

### Step 5: Wait & Enable HTTPS
1. DNS takes 5-60 minutes to propagate
2. Once live, go back to repo Settings → Pages
3. Check "Enforce HTTPS"
4. Done! Visit https://hydra-terra.com.au

---

## 📦 What's Included

**Core Suite (8 Tools):**
- Project Tracker Pro
- Appointment Scheduler
- Invoice & Quote Generator
- Duplicate Detector Pro
- Branding Customizer
- Animation Studio Pro
- Task Manager
- Automation Master Controller

**Add-on Suite (4 Tools):**
- Client Dashboard
- Team Portal
- Advanced Analytics
- Expense & Payroll Manager

**Launchers (Windows/Mac/Linux):**
- Launch-StartHere.bat (Windows)
- Launch-StartHere.sh (Mac/Linux)
- Individual tool launchers (.bat files)

---

## 🔧 Local Use (No Internet Required)

### Windows:
Double-click `Launch-StartHere.bat`

### Mac/Linux:
1. Open Terminal
2. Navigate to the GoogleSites folder
3. Run: `chmod +x Launch-StartHere.sh`
4. Run: `./Launch-StartHere.sh`

---

## 📞 Support

**Hydra-Terra Landscape Solutions**
- ABN: 19 630 905 514
- Email: admin@hydra-terra.com.au
- Phone: 0426 398 510
- Website: www.hydra-terra.com.au

---

## 🔒 Certificate

See `HYDRA-TERRA_CERTIFICATE.txt` for authenticity verification.

---

## ⚡ Quick Links

After deployment, access your suite at:
- https://hydra-terra.com.au (redirects to dashboard)
- https://hydra-terra.com.au/hydra-terra-2025-world.html (direct dashboard)

All tools work offline in your browser - no server required!
